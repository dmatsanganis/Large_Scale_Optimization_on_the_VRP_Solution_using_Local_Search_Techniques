from VRP_Model import *
from SolutionDrawer import *

class Solution:
    def __init__(self):
        self.cost = 0.0
        self.routes = []

class RelocationMove(object):
    def __init__(self):
        self.originRoutePosition = None
        self.targetRoutePosition = None
        self.originNodePosition = None
        self.targetNodePosition = None
        self.costChangeOriginRt = None
        self.costChangeTargetRt = None
        self.moveCost = None

    def Initialize(self):
        self.originRoutePosition = None
        self.targetRoutePosition = None
        self.originNodePosition = None
        self.targetNodePosition = None
        self.costChangeOriginRt = None
        self.costChangeTargetRt = None
        self.moveCost = 10 ** 9

class CustomerInsertionAllPositions(object):
    def __init__(self):
        self.customer = None
        self.route = None
        self.insertionPosition = None
        self.cost = 10 ** 9

class Solver:
    def __init__(self, m):
        self.allNodes = m.allNodes
        self.customers = m.customers
        self.depot = m.allNodes[0]
        self.distanceMatrix = m.matrix
        self.capacity = m.capacity
        self.sol = None
        self.bestSolution = None
        self.rtCounter = 0
        self.rtInd = -1
        self.iterations = None

    def solve(self):
        self.MinimumInsertions()
        self.ReportSolution(self.sol)
        #self.LocalSearch(0)
        #self.ReportSolution(self.sol)

        return self.sol

    def MinimumInsertions(self):
        modelIsFeasible = True
        self.sol = Solution()
        insertions = 0
        distFrombase = self.distanceMatrix[0]
        closest26points = sorted(range(1, len(distFrombase)), key=lambda k: distFrombase[k])[:26]
        insPos = 0
        for i in closest26points:
            rt = Route(self.depot, self.capacity)
            self.sol.routes.append(rt)
            randomInsertion = CustomerInsertionAllPositions()
            randomInsertion.customer = self.allNodes[i]
            randomInsertion.customer.demand = self.allNodes[i].demand
            randomInsertion.route = self.sol.routes[closest26points.index(i)]
            randomInsertion.cost = self.distanceMatrix[0][i]
            randomInsertion.insertionPosition = insPos
            self.ApplyCustomerInsertionAllPositions(randomInsertion)
            insertions += 1
            self.rtCounter = 1

        while insertions < len(self.customers):
            bestInsertion = CustomerInsertionAllPositions()
            if self.rtInd == 25:
                self.rtInd = 0
            else:
                self.rtInd += 1

            lastOpenRoute: Route = self.GetLastOpenRoute()

            if lastOpenRoute is not None:
                self.IdentifyBestInsertionAllPositions(bestInsertion, lastOpenRoute)

            if bestInsertion.customer is not None:
                self.ApplyCustomerInsertionAllPositions(bestInsertion)
                insertions += 1

            else:
                # If there is an empty available route
                if lastOpenRoute is not None and len(lastOpenRoute.sequenceOfNodes) == 2:
                    modelIsFeasible = False
                    break
                # If there is no empty available route and no feasible insertion was identified
                else:
                    self.rtCounter += 1

        if modelIsFeasible == False:
            print('FeasibilityIssue')

        #self.TestSolution()

    def GetLastOpenRoute(self):
        if self.rtCounter == 0:
            return None
        else:
            return self.sol.routes[self.rtInd]

    def IdentifyBestInsertionAllPositions(self, bestInsertion, rt):
        for i in range(0, len(self.customers)):
            candidateCust: Node = self.customers[i]
            if candidateCust.isRouted is False:
                if rt.load + candidateCust.demand <= rt.capacity:
                    for j in range(0, len(rt.sequenceOfNodes) - 1):
                        A = rt.sequenceOfNodes[j]
                        B = rt.sequenceOfNodes[j + 1]
                        costAdded = self.distanceMatrix[A.ID][candidateCust.ID] + self.distanceMatrix[candidateCust.ID][
                            B.ID]
                        costRemoved = self.distanceMatrix[A.ID][B.ID]
                        trialCost = costAdded - costRemoved

                        if trialCost < bestInsertion.cost:
                            bestInsertion.customer = candidateCust
                            bestInsertion.route = rt
                            bestInsertion.cost = trialCost
                            bestInsertion.insertionPosition = j

    def ApplyCustomerInsertionAllPositions(self, bestInsertion):
        insCustomer = bestInsertion.customer
        rt = bestInsertion.route
        # before the second depot occurrence
        insIndex = bestInsertion.insertionPosition
        rt.sequenceOfNodes.insert(insIndex + 1, insCustomer)
        rt.cost += bestInsertion.cost
        rt.load += insCustomer.demand
        insCustomer.isRouted = True

    def ReportSolution(self, sol):
        allrt_costs = []

        for i in range(0, len(sol.routes)):
            rt = sol.routes[i]

            for j in range (0, len(rt.sequenceOfNodes)):
                print(rt.sequenceOfNodes[j].ID, end=' ')

            print(rt.cost)
            allrt_costs.append(rt.cost)

        self.sol.cost = max(allrt_costs)
        print(self.sol.cost)

        # if self.iterations is not None:
        #     iterationStr = "The objective function was trapped in the optimal cost of {} hours after {} iterations." \
        #         .format(str(self.CalculateTotalCost(self.sol)), str(self.iterations))
        #     print(iterationStr)