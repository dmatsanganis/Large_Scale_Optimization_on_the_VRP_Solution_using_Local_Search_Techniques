from VRP_Model import *
from SolutionDrawer import *

class Solution:
    def __init__(self):
        self.cost = 0.0
        self.routes = []

class RelocationMove(object):
    def __init__(self):
        self.originRoutePosition = None
        self.targetRoutePosition = None
        self.originNodePosition = None
        self.targetNodePosition = None
        self.costChangeOriginRt = None
        self.costChangeTargetRt = None
        self.moveCost = None

    def Initialize(self):
        self.originRoutePosition = None
        self.targetRoutePosition = None
        self.originNodePosition = None
        self.targetNodePosition = None
        self.costChangeOriginRt = None
        self.costChangeTargetRt = None
        self.moveCost = 10 ** 9


class SwapMove(object):
    def __init__(self):
        self.positionOfFirstRoute = None
        self.positionOfSecondRoute = None
        self.positionOfFirstNode = None
        self.positionOfSecondNode = None
        self.costChangeFirstRt = None
        self.costChangeSecondRt = None
        self.moveCost = None
    def Initialize(self):
        self.positionOfFirstRoute = None
        self.positionOfSecondRoute = None
        self.positionOfFirstNode = None
        self.positionOfSecondNode = None
        self.costChangeFirstRt = None
        self.costChangeSecondRt = None
        self.moveCost = 10 ** 9


class CustomerInsertion(object):
    def __init__(self):
        self.customer = None
        self.route = None
        self.cost = 10 ** 9

class CustomerInsertionAllPositions(object):
    def __init__(self):
        self.customer = None
        self.route = None
        self.insertionPosition = None
        self.cost = 10 ** 9

class TwoOptMove(object):
    def __init__(self):
        self.positionOfFirstRoute = None
        self.positionOfSecondRoute = None
        self.positionOfFirstNode = None
        self.positionOfSecondNode = None
        self.moveCost = None
    def Initialize(self):
        self.positionOfFirstRoute = None
        self.positionOfSecondRoute = None
        self.positionOfFirstNode = None
        self.positionOfSecondNode = None
        self.moveCost = 10 ** 9





class Solver:
    def __init__(self, m):
        self.allNodes = m.allNodes
        self.customers = m.customers
        self.depot = m.allNodes[0]
        self.distanceMatrix = m.matrix # It refers to the timematrix
        self.capacity = m.capacity
        self.sol = None
        self.bestSolution = None
        self.iterations = None
        # self.rtInd = -1
        # self.rtCounter = 0

    def solve(self):
        #self.SetRoutedFlagToFalseForAllCustomers()
        self.ApplyNearestNeighborMethod()
        #self.MinimumInsertions()
        self.ReportSolution(self.sol)
        #self.LocalSearch(2)
        #self.ReportSolution(self.sol)
        return self.sol

    def ApplyNearestNeighborMethod(self):
        modelIsFeasible = True
        self.sol = Solution()
        insertions = 0

        while (insertions < len(self.customers)):
            bestInsertion = CustomerInsertion()
            lastOpenRoute: Route = self.GetLastOpenRoute()

            if lastOpenRoute is not None:
                self.IdentifyBestInsertion(bestInsertion, lastOpenRoute)

            if (bestInsertion.customer is not None):
                self.ApplyCustomerInsertion(bestInsertion)
                insertions += 1
            else:
                # If there is an empty available route
                if lastOpenRoute is not None and len(lastOpenRoute.sequenceOfNodes) == 2:
                    modelIsFeasible = False
                    break
                else:
                    # The first step of the algorithm to start one route that has only depot as a node
                    rt = Route(self.depot, self.capacity)
                    self.sol.routes.append(rt)

        if len(self.sol.routes) != 26:
            while len(self.sol.routes) < 26:
                rt = Route(self.depot, self.capacity)
                self.sol.routes.append(rt)


        if (modelIsFeasible == False):
            print('FeasibilityIssue')
            # reportSolution

    def GetLastOpenRoute(self):
        if len(self.sol.routes) == 0:
            return None
        else:
            return self.sol.routes[-1]

    # def IdentifyBestInsertion(self, bestInsertion, rt):
    #     for i in range(0, len(self.customers)):
    #         candidateCust:Node = self.customers[i]
    #         if candidateCust.isRouted is False:
    #             if rt.load + candidateCust.demand <= rt.capacity:
    #                 lastNodePresentInTheRoute = rt.sequenceOfNodes[-2]
    #                 trialCost = self.distanceMatrix[lastNodePresentInTheRoute.ID][candidateCust.ID]
    #                 if trialCost < bestInsertion.cost:
    #                     bestInsertion.customer = candidateCust
    #                     bestInsertion.route = rt
    #                     bestInsertion.cost = trialCost

    def ApplyCustomerInsertion(self, bestInsertion):
        insCustomer = bestInsertion.customer
        rt = bestInsertion.route
        #before the second depot occurrence
        insIndex = len(rt.sequenceOfNodes) - 1
        rt.sequenceOfNodes.insert(insIndex, insCustomer)

        beforeInserted = rt.sequenceOfNodes[-3]

        costAdded = self.distanceMatrix[beforeInserted.ID][insCustomer.ID] + self.distanceMatrix[insCustomer.ID][self.depot.ID]
        costRemoved = self.distanceMatrix[beforeInserted.ID][self.depot.ID]

        rt.cost += costAdded - costRemoved

        rt.load += insCustomer.demand

        insCustomer.isRouted = True

    def ReportSolution(self, sol):
        for i in range(0, len(sol.routes)):
            rt = sol.routes[i]
            for j in range (0, len(rt.sequenceOfNodes)):
                print(rt.sequenceOfNodes[j].ID, end=' ')
            print(rt.cost)
        print (self.CalculateTotalCost(self.sol))

        # if self.iterations is not None:
        #     iterationStr = "The objective function was trapped in the optimal cost of {} hours after {} iterations." \
        #         .format(str(self.CalculateTotalCost(self.sol)), str(self.iterations))
        #     print(iterationStr)

    def CalculateTotalCost(self, sol):
        # We change the cost calculation method as it should return the max time needed to serve the last customer
        # in every route and then find the global maximum of all routes.
        c = []
        for i in range(0, len(sol.routes)):
            rt = sol.routes[i]
            r = []
            for j in range(0, len(rt.sequenceOfNodes) - 1):
                a = rt.sequenceOfNodes[j]
                b = rt.sequenceOfNodes[j + 1]
                r.append(self.distanceMatrix[a.ID][b.ID])
            c.append(sum(r))
        self.sol.cost = max(c)
        return self.sol.cost

    def IdentifyBestInsertion(self, bestInsertion, rt):
        for i in range(0, len(self.customers)):
            candidateCust:Node = self.customers[i]
            if candidateCust.isRouted is False:
                for rt in self.sol.routes:
                    if rt.load + candidateCust.demand <= rt.capacity:
                        lastNodePresentInTheRoute = rt.sequenceOfNodes[-2]
                        trialCost = self.distanceMatrix[lastNodePresentInTheRoute.ID][candidateCust.ID]
                        if trialCost < bestInsertion.cost:
                            bestInsertion.customer = candidateCust
                            bestInsertion.route = rt
                            bestInsertion.cost = trialCost