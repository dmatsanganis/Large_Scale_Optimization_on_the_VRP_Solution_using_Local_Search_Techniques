## Large_Scale_Optimization
![image](https://user-images.githubusercontent.com/34712449/194163458-8e5b16b8-9d1b-4337-99ca-19e6803c9822.png)
![image](https://user-images.githubusercontent.com/34712449/209637332-97357d17-a05a-4b42-a872-d15fb7dad71d.png)  

## Documentation

You can find further information regarding the development of this project under the project's documentation file - see the [Documentation](/Documentation.pdf) for details. 

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details

## Contributors

- [X] [Julia Baardse](-) 
- [X] [Dimitris Matsanganis](https://github.com/dimitrismatsanganis) 
- [X] [Foteini Nefeli](https://github.com/FoteiniNefeli)
- [X] [Eva Routsi](https://github.com/EvaRoutsi)
