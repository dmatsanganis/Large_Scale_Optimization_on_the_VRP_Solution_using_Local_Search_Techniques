    def FindBestRelocationMove(self, rm):
        # Find the index of the max cost routes index in the routes solution list
        rtTest = Route(self.depot, self.capacity)
        rtTest.cost = -1
        rtMax = Route(self.depot, self.capacity)
        rtMaxIndex = -1

        for i in range(0, len(self.sol.routes)):
            rt: Route = self.sol.routes[i]
            if rt.cost > rtTest.cost:
                rtMax = rt
                rtMaxIndex = i

        print("The index of the max cost route is", rtMaxIndex)

        # First case the origin route is the max cost route and the target route is a different route
        originRouteIndex = rtMaxIndex
        rt1:Route = self.sol.routes[originRouteIndex]
        for originNodeIndex in range(1, len(rt1.sequenceOfNodes) - 1):
            A = rt1.sequenceOfNodes[originNodeIndex - 1]
            B = rt1.sequenceOfNodes[originNodeIndex]
            C = rt1.sequenceOfNodes[originNodeIndex + 1]

            for targetRouteIndex in range(0, originRouteIndex):
                rt2: Route = self.sol.routes[targetRouteIndex]

                for targetNodeIndex in range(0, len(rt2.sequenceOfNodes) - 1):

                    F = rt2.sequenceOfNodes[targetNodeIndex]
                    G = rt2.sequenceOfNodes[targetNodeIndex + 1]

                    if rt2.load + B.demand > rt2.capacity:
                        continue

                    originRtCostChange = self.distanceMatrix[A.ID][C.ID] - self.distanceMatrix[A.ID][B.ID] - self.distanceMatrix[B.ID][C.ID]
                    targetRtCostChange = self.distanceMatrix[F.ID][B.ID] + self.distanceMatrix[B.ID][G.ID] - self.distanceMatrix[F.ID][G.ID]

                    moveCost = originRtCostChange

                    if (moveCost < rm.moveCost and rt2.cost + targetRtCostChange < rt1.cost + moveCost):
                        self.StoreBestRelocationMove(originRouteIndex, targetRouteIndex, originNodeIndex, targetNodeIndex, moveCost, originRtCostChange, targetRtCostChange, rm)


        for originNodeIndex in range(1, len(rt1.sequenceOfNodes) - 1):
            A = rt1.sequenceOfNodes[originNodeIndex - 1]
            B = rt1.sequenceOfNodes[originNodeIndex]
            C = rt1.sequenceOfNodes[originNodeIndex + 1]

            for targetRouteIndex in range(originRouteIndex + 1,len(self.sol.routes)):
                rt2: Route = self.sol.routes[targetRouteIndex]

                for targetNodeIndex in range(0, len(rt2.sequenceOfNodes) - 1):

                    F = rt2.sequenceOfNodes[targetNodeIndex]
                    G = rt2.sequenceOfNodes[targetNodeIndex + 1]

                    if rt2.load + B.demand > rt2.capacity:
                        continue

                    originRtCostChange = self.distanceMatrix[A.ID][C.ID] - self.distanceMatrix[A.ID][B.ID] - \
                                         self.distanceMatrix[B.ID][C.ID]
                    targetRtCostChange = self.distanceMatrix[F.ID][B.ID] + self.distanceMatrix[B.ID][G.ID] - \
                                         self.distanceMatrix[F.ID][G.ID]

                    moveCost = originRtCostChange

                    if (moveCost < rm.moveCost and rt2.cost + targetRtCostChange < rt1.cost + moveCost):
                        self.StoreBestRelocationMove(originRouteIndex, targetRouteIndex, originNodeIndex, targetNodeIndex, moveCost, originRtCostChange, targetRtCostChange, rm)


        # Second case the origin route is the max cost route and the target route is also the max cost target route
        targetRouteIndex = originRouteIndex
        rt2: Route = self.sol.routes[targetRouteIndex]
        for originNodeIndex in range(1, len(rt1.sequenceOfNodes) - 1):
            A = rt1.sequenceOfNodes[originNodeIndex - 1]
            B = rt1.sequenceOfNodes[originNodeIndex]
            C = rt1.sequenceOfNodes[originNodeIndex + 1]
            for targetNodeIndex in range(0, len(rt2.sequenceOfNodes) - 1):
                if (targetNodeIndex == originNodeIndex or targetNodeIndex == originNodeIndex - 1):
                    continue
                F = rt2.sequenceOfNodes[targetNodeIndex]
                G = rt2.sequenceOfNodes[targetNodeIndex + 1]

                originRtCostChange = self.distanceMatrix[A.ID][C.ID] - self.distanceMatrix[A.ID][B.ID] - self.distanceMatrix[B.ID][C.ID]
                targetRtCostChange = self.distanceMatrix[F.ID][B.ID] + self.distanceMatrix[B.ID][G.ID] - self.distanceMatrix[F.ID][G.ID]

                moveCost = originRtCostChange + targetRtCostChange

                if (moveCost < rm.moveCost):
                    self.StoreBestRelocationMove(originRouteIndex, targetRouteIndex, originNodeIndex, targetNodeIndex, moveCost, originRtCostChange, targetRtCostChange, rm)

