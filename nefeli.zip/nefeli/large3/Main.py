from Solver5 import *

m = Model()
m.BuildModel()
s = Solver(m)
sol = s.solve()
print("xaxaxaxa ")
print("xaxaxaxa ")





